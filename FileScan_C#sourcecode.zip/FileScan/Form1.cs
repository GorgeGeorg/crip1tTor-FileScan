﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace FileScan
{
    public partial class Form1 : Form
    {
        List<String> SourceFiles;
        string FolderDestination = "";
        string FolderSource = "";
        bool bAbort = false;
        int NumFiles;

        public Form1()
        {
            InitializeComponent();
        }

        private void Label1_Click(object sender, EventArgs e)
        {
            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                FolderSource = folderBrowserDialog1.SelectedPath;
                GetFiles(FolderSource);
            }
            else
            {
                FolderSource = "";
                label3.Text = "Status: No source selected";
            }
                label1.Text = "Source Folder>" + FolderSource;
            button1.Enabled = false;
            EnableScan();
        }

        private void Label2_Click(object sender, EventArgs e)
        {
            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
                FolderDestination = folderBrowserDialog1.SelectedPath;
            else
                FolderDestination = "";
            label2.Text = "Destination >" + FolderDestination;
            EnableScan();
        }
            private void CheckBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (FolderSource != "")
                GetFiles(FolderSource);
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            if (button1.Text == "Scan")
            {
                bAbort = false;
                button1.Text = "Abort";
                Scan();
 }
            else
            {
                button1.Text = "Aborting";
                button1.Enabled = false;
                bAbort = true;
            }
        }
        private void EnableScan()
        {
            try
            {
                button1.Enabled = (SourceFiles.Count > 0 && FolderDestination != "" && FolderDestination != FolderSource);
            }
            catch
            {
                button1.Enabled = false;
            }
        }

        private void Scan()
        {
             bool bMove;
            string errMsg="";
            int count = 0;
            int keep = 0;
            int errs;
            byte[] DataArray = new byte[16];
            label1.Enabled = false;
            label2.Enabled = false;
            checkBox1.Enabled = false;
            label3.Text = "Status: Scaning files";
            foreach (String Sfile in SourceFiles)
            {
                if (!bAbort)
                {
                    bMove = true;
                    using (FileStream fs = new FileStream(Sfile, FileMode.Open, FileAccess.Read, FileShare.Read))
                    {
                        if (fs.Read(DataArray, 0, 16) > 0)
                        {
                            for (int i = 0; i < 16; i++)
                            {
                                if (DataArray[i] != 0)
                                {
                                    fs.Seek(-16, SeekOrigin.End);
                                    fs.Read(DataArray, 0, 16);
                                    if ((DataArray[15] == 0x5f && DataArray[14] == 0x72 && DataArray[13] == 0x30 && DataArray[12] == 0x54 && DataArray[11] == 0x74 && DataArray[10] == 0x70) == false)
                                        bMove = false;
                                    i = 16;
                                }
                            }
                        }
                    }
                    if (bMove)
                    {
                        try
                        {
                            File.Move(Sfile, FolderDestination + Sfile.Substring(Sfile.LastIndexOf("\\")));

                        }
                        catch (Exception e)
                        {
                            if (File.Exists(FolderDestination + Sfile.Substring(Sfile.LastIndexOf("\\"))))
                            {
                                errs = 0;
                                while (File.Exists(FolderDestination + Sfile.Substring(Sfile.LastIndexOf("\\")) + "_" + errs.ToString()))
                                    errs++;
                                File.Move(Sfile, FolderDestination + Sfile.Substring(Sfile.LastIndexOf("\\")) + "_" + errs.ToString());
                            }
                            else
                            {
                                errMsg = e.Message;
                                break;
                            }
                        }
                        count += 1;
                    }
                    else
                        keep++;
                    label3.Text = "Status: " + count.ToString() + " Bad Files Moved   " + keep.ToString() + "  files kept  # left:" + (NumFiles - count - keep).ToString();
                    if (((keep + count) % 10) == 0)
                    {
                        Application.DoEvents();
                    }
                }
            }
            label1.Enabled = true;
            label2.Enabled = true;
            checkBox1.Enabled = true;
            button1.Text = "Scan";
            bAbort = false;
            button1.Enabled = false;
            label3.Text = "Status: Finished  " + count.ToString() + " Bad Files Moved  " + keep.ToString() + "  files kept";
            if (errMsg != "")
                throw new Exception(errMsg);
        }
        private void GetFiles(string Fpath)
        {
            label3.Text = "Status: checking for files";
            label3.Refresh();
            this.Enabled = false;
            SourceFiles = new List<string>();
            if (checkBox1.Checked)
               SourceFiles = Directory.GetFiles(Fpath, "*.*", SearchOption.AllDirectories).ToList();
            else
               SourceFiles = Directory.GetFiles(Fpath, "*.*", SearchOption.TopDirectoryOnly).ToList();
            NumFiles = SourceFiles.Count;
            label3.Text = "Status: " + NumFiles.ToString() + "  Files found";
            this.Enabled = true;

    }

        private void Button2_Click(object sender, EventArgs e)
        {
            string message = "This Program scans for files that are either blank (first 16 bytes anyway)";
            message += Environment.NewLine + "or have been encrypted by the crip1tTor ransonware virus";
            message += Environment.NewLine + "and moves those files to a new folder";
            message += Environment.NewLine + "click on the Source Folder>  or  Destination Folder>  text";
            message += Environment.NewLine + "to specify those folders";
            MessageBox.Show(message, "About FileScan");
        }
    }
}
